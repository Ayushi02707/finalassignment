package ayushi.service;
import java.util.List;
import java.util.Optional;

import ayushi.model.Employee;



public interface EmployeeService {

	Integer saveEmployee(Employee e);
	void updateEmployee(Employee e);

	void deleteOneEmployee(Integer id);

	Optional<Employee> getOneEmployee(Integer id);
	List<Employee> getAllEmployees();

	boolean isEmployeeExist(Integer id);
}
