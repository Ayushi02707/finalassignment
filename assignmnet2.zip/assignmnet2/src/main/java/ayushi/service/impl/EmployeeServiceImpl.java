package ayushi.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ayushi.model.Employee;
import ayushi.repo.EmployeeRepository;
import ayushi.service.EmployeeService;


@Service
public  class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public Integer saveEmployee(Employee e) {
		e = repo.save(e);
		return e.getId();
	}

	@Override
	public void updateEmployee(Employee e) {
		repo.save(e);
	}
   @Override
	public void deleteOneEmployee(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Employee> getOneEmployee(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return repo.findAll();
	}

	@Override
	public boolean isEmployeeExist(Integer id) {
		return repo.existsById(id);
	}

}
