package ayushi.util;

import org.springframework.boot.SpringApplication;
import ayushi.model.Employee;

public class EmployeeUtil {
public static void main(String[] args) throws Exception {
	SpringApplication.run(EmployeeUtil.class, args);
}

public void mapToActualObject(Employee actual, Employee employee) {
	
	if(employee.getName()!=null)
        actual.setName(employee.getName());
    actual.setEmail(employee.getEmail());
    if(employee.getBranch()!=null)
        actual.setBranch(employee.getBranch());
    actual.setAddr(employee.getAddr());
}

}
